
<?php
	$w = $_GET['w'];
	$h = $_GET['h'];
	// *** Include the class
	include("resize-class.php");

	// *** 1) Initialise / load image
	$resizeObj = new resize('sample.jpg');	
	
	// *** 2) Resize image (options: exact, portrait, landscape, auto, crop)
	$resizeObj->resizeImage($w, $h, 'crop');
//
//	// *** 3) Save image
	$resizeObj->saveImage('sample-resized.jpg');

?>
<html>
	<body>
		<a style="display:table-cell;background:#eee;border: 1px solid #ccc;float:left;width:400px;height:400px;text-align:center;vertical-align:middle"><img src="sample-resized.jpg" /></a>
	</body>
</html>